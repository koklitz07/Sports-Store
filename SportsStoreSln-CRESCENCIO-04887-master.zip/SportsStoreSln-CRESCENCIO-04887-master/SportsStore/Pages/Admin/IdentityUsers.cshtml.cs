using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SportsStore.Pages.Admin
{
    public class IdentityUsersModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
